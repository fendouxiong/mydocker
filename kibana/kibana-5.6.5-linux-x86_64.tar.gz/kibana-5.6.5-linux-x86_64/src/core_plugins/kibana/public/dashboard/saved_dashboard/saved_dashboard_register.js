export function savedDashboardRegister(savedDashboards) {
  return savedDashboards;
}
