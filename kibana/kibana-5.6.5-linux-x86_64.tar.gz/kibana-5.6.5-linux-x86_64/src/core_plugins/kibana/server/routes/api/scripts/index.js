'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (server) {
  (0, _register_languages.registerLanguages)(server);
};

var _register_languages = require('./register_languages');

module.exports = exports['default'];
